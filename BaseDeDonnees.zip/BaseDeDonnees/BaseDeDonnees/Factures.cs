﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace BaseDeDonnees
{
    public partial class Factures : Form
    {
        Form caller;
        List<List<String>> nouvelleFacture;

        public Factures(Form caller)
        {
            this.Caller = caller;
            InitializeComponent();
        }

        public Form Caller
        {
            get
            {
                return caller;
            }

            set
            {
                caller = value;
            }
        }

        // Shows Administration form for clients, prefilled with selected client
        private void BTN_Details_Click(object sender, EventArgs e)
        {
            MySqlConnection connection = ((Connector)this.Caller).Connection;
            Administration results = new Administration(this);
            ((Connector)this.Caller).Results = results;
            // Attempting Database connection
            try
            {
                connection.Open();
            }
            catch (Exception ex)
            {
                connection.Close();
                MessageBox.Show(ex.Message);
                return;
            }

            // Getting data
            MySqlCommand command = connection.CreateCommand();
            string sqlCommand = "SELECT * FROM client";
            command.CommandText = sqlCommand;
            MySqlDataReader reader = command.ExecuteReader();

            // Creating detail form
            ((Connector)this.Caller).createClientResultsForm(reader);
            results.Caller = this;

            // Controls control
            ComboBox CB_Ncli = results.Controls.Find("CB_Ncli", true).FirstOrDefault() as ComboBox;
            CB_Ncli.Text = this.Controls.Find("CB_Ncli", true).FirstOrDefault().Text;
            ((Button)results.Controls.Find("BTN_Modifier", true).FirstOrDefault()).Enabled = false;
            ((Button)results.Controls.Find("BTN_Supprimer", true).FirstOrDefault()).Enabled = false;
            results.Height -= 50;
            
            this.Hide();
        }

        private void BTN_GenFacture_Click(object sender, EventArgs e)
        {
            if (((Button)sender).Text == "Générer / modifier \r\nune facture" && CB_Ncli.Text.Length * CB_Ncom.Text.Length > 0)
            {
                // Getting Produits data
                MySqlConnection connection = ((Connector)this.Caller).Connection;
                Administration results = new Administration(this);
                ((Connector)this.Caller).Results = results;
                // Attempting Database connection
                try
                {
                    connection.Open();
                }
                catch (Exception ex)
                {
                    connection.Close();
                    MessageBox.Show(ex.Message);
                    return;
                }

                // Getting data
                MySqlCommand command = connection.CreateCommand();
                string sqlCommand = "SELECT npro, libelle, prix, qstock FROM produit";
                command.CommandText = sqlCommand;
                MySqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    CB_Npro.Items.Add(reader.GetString(0));
                    CB_Produit.Items.Add(reader.GetString(1));
                    CB_Prix.Items.Add(reader.GetString(2));
                    CB_QuantiteStock.Items.Add(reader.GetString(3));
                }
                reader.Close();
                connection.Close();

                // We need to update commandes list
                if ((string)((Control)sender).Tag == "0")
                {
                    ((ComboBox)this.Controls.Find("CB_Ncom", true).FirstOrDefault()).Items.Clear();
                    ((ComboBox)this.Controls.Find("CB_Datecom", true).FirstOrDefault()).Items.Clear();
                    command = connection.CreateCommand();
                    sqlCommand = "SELECT ncom, DATE_FORMAT(datecom, '%Y-%m-%d') FROM commande where ncli = '" + this.Controls.Find("CB_Ncli", true).FirstOrDefault().Text + "'";
                    command.CommandText = sqlCommand;
                    reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        ((ComboBox)this.Controls.Find("CB_Ncom", true).FirstOrDefault()).Items.Add(reader.GetString(0));
                        ((ComboBox)this.Controls.Find("CB_Datecom", true).FirstOrDefault()).Items.Add(reader.GetString(1));
                    }
                    reader.Close();
                    ((ComboBox)this.Controls.Find("CB_Ncom", true).FirstOrDefault()).Text = "";
                    ((ComboBox)this.Controls.Find("CB_Datecom", true).FirstOrDefault()).Text = "";
                }


                this.nouvelleFacture = new List<List<string>>();
                this.Size = new Size(550, 500);
                ((Button)sender).Text = "Valider la commande";

            }
            else if (((Button)sender).Text == "Valider la commande")
            {
                int ncom = int.Parse(CB_Ncom.Text);

                // Attenpting commande update
                MySqlConnection connection = ((Connector)this.Caller).Connection;
                Administration results = new Administration(this);
                ((Connector)this.Caller).Results = results;
                // Attempting Database connection
                try
                {
                    connection.Open();
                }
                catch (Exception ex)
                {
                    connection.Close();
                    MessageBox.Show(ex.Message);
                    return;
                }
                // Updating detail
                MySqlCommand command;
                string sqlCommand;
                MySqlDataReader reader;
                foreach (List<String> elem in this.nouvelleFacture)
                {
                    command = connection.CreateCommand();
                    sqlCommand = "INSERT IGNORE INTO detail VALUES ('" + CB_Ncom.Text + "', '" + elem[0] + "', '" + int.Parse(elem[1]) + "')";
                    command.CommandText = sqlCommand;
                    reader = command.ExecuteReader();
                    reader.Close();
                }

                //Updating command
                command = connection.CreateCommand();
                sqlCommand = "INSERT IGNORE INTO commande VALUES ('" + CB_Ncom.Text + "', '" + CB_Ncli.Text + "', '" + CB_DateCom.Text + "')";
                command.CommandText = sqlCommand;
                reader = command.ExecuteReader();
                reader.Close();

                MessageBox.Show("Commande mise à jour !");
                ((Button)sender).Text = "Générer / modifier \r\nune facture";
                this.Size = new Size(550, 350);
                connection.Close();
            }
        }

        private void NUD_Quantite_ValueChanged(object sender, EventArgs e)
        {
            if (((ComboBox)this.Controls.Find("CB_QuantiteStock", true).FirstOrDefault()).Text.Length > 0)
            {
                if (((NumericUpDown)sender).Value > int.Parse(CB_QuantiteStock.Text))
                {
                    ((NumericUpDown)sender).Value = int.Parse(CB_QuantiteStock.Text);
                }
            }
        }

        private void BTN_RemoveProduct_Click(object sender, EventArgs e)
        {

            if (CB_Produit.Text.Length * NUD_Quantite.Value > 0 )
            {
                for (int i = 0; i < this.nouvelleFacture.Count; i++)
                {
                    if( this.nouvelleFacture[i][2] == CB_Produit.Text)
                    {
                        return;
                    }
                }
                this.nouvelleFacture.Add(new List<string>() { CB_Npro.Text, NUD_Quantite.Value.ToString(), CB_Produit.Text, CB_Produit.SelectedIndex.ToString() });
               LB_Details.Items.Add(
                   CB_Produit.Text + 
                   "     prix " + CB_Prix.Text + 
                   "€     quantite " + NUD_Quantite.Value.ToString() + 
                   "     (total " + int.Parse(CB_Prix.Text) * NUD_Quantite.Value + "€)"
               );
            }
        }

        private void BTN_AddProduct_Click(object sender, EventArgs e)
        {
            try
            {
               LB_Details.Items.RemoveAt(LB_Details.SelectedIndex);
                for (int i = 0; i < this.nouvelleFacture.Count; i++)
                {
                    if (CB_Produit.Items[int.Parse(this.nouvelleFacture[i][2])].ToString() == this.nouvelleFacture[i][0])             
                    {
                        this.nouvelleFacture.RemoveAt(i);
                    }
                }
            }
            catch (ArgumentOutOfRangeException ex)
            {

            }
            
        }
    }
}
