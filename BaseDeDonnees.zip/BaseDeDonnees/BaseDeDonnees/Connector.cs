﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace BaseDeDonnees
{
    public partial class Connector : Form
    {
        MySqlConnection connection;
        Form results;

        public MySqlConnection Connection
        {
            get
            {
                return connection;
            }

            set
            {
                connection = value;
            }
        }

        public Form Results
        {
            get
            {
                return results;
            }

            set
            {
                results = value;
            }
        }

        public Connector()
        {
            InitializeComponent();

            // DEBUG : Prefilling connection parameters
            TB_Source.Text = "localhost";
            TB_InitCatalog.Text = "comcli";
            TB_Table.Text = "client";
            TB_User.Text = "root";
            TB_Password.Text = "";
        }

        private void BTN_Connection_Click(object sender, EventArgs e)
        {

            if (TB_InitCatalog.TextLength * TB_Source.TextLength * TB_User.TextLength * TB_Table.TextLength > 0)
            {

                // Preparing connection
                string connectorParams =
                    "Data Source=" + TB_Source.Text + ";" +
                    "Database=" + TB_InitCatalog.Text + ";" +
                    "UID=" + TB_User.Text + ";" +
                    "Password=" + TB_Password.Text + ";";
                this.Connection = new MySqlConnection(connectorParams);

                // Attempting Database connection
                try
                {
                    this.Connection.Open();
                }
                catch (Exception ex)
                {
                    this.Connection.Close();
                    MessageBox.Show(ex.Message);
                    return;
                }

                if (CB_Mode.Text == "Administration")
                {
                    // Getting data
                    MySqlCommand command = this.Connection.CreateCommand();
                    string sqlCommand = "SELECT * FROM " + TB_Table.Text;
                    command.CommandText = sqlCommand;
                    Results = new Administration(this);
                    MySqlDataReader reader = command.ExecuteReader();

                    switch (TB_Table.Text)
                    {
                        case "client":
                            createClientResultsForm(reader);
                            break;
                        case "produit":
                            createProduitResultsForm(reader);
                            break;
                        case "commande":
                            createCommandeResultsForm(reader);
                            break;

                        default:
                            break;
                    }
                }
                else if (CB_Mode.Text == "Factures")
                {
                    // Getting data
                    MySqlCommand command = this.Connection.CreateCommand();
                    string sqlCommand = "SELECT ncli, nom FROM client";
                    command.CommandText = sqlCommand;
                    Results = new Factures(this);
                    MySqlDataReader reader = command.ExecuteReader();

                    // Creating client listbox
                    ComboBox CB_Ncli = Results.Controls.Find("CB_Ncli", true).FirstOrDefault() as ComboBox;
                    ComboBox CB_Nom = Results.Controls.Find("CB_Nom", true).FirstOrDefault() as ComboBox;
                    ComboBox CB_Ncom = Results.Controls.Find("CB_Ncom", true).FirstOrDefault() as ComboBox;
                    ComboBox CB_Datecom = Results.Controls.Find("CB_Datecom", true).FirstOrDefault() as ComboBox;
                    ComboBox CB_Produit = Results.Controls.Find("CB_Produit", true).FirstOrDefault() as ComboBox;
                    ComboBox CB_Prix = Results.Controls.Find("CB_Prix", true).FirstOrDefault() as ComboBox;
                    ComboBox CB_QuantiteStock = Results.Controls.Find("CB_QuantiteStock", true).FirstOrDefault() as ComboBox; 
                    CB_Ncli.SelectedIndexChanged += new System.EventHandler(this.MAJCommandes);
                    CB_Nom.SelectedIndexChanged += new System.EventHandler(this.MAJCommandes);
                    CB_Ncom.SelectedIndexChanged += new System.EventHandler(this.MAJCommandes);
                    CB_Datecom.SelectedIndexChanged += new System.EventHandler(this.MAJCommandes);
                    CB_Produit.SelectedIndexChanged += new System.EventHandler(this.MAJIndexes);
                    CB_Prix.SelectedIndexChanged += new System.EventHandler(this.MAJIndexes);
                    CB_QuantiteStock.SelectedIndexChanged += new System.EventHandler(this.MAJIndexes);

                    // Filling client listbox
                    while (reader.Read())
                    {
                        int i = 0;
                        CB_Ncli.Items.Add(reader.GetString(i++));
                        CB_Nom.Items.Add(reader.GetString(i));
                    }

                    this.Connection.Close();
                    Results.FormClosing += new FormClosingEventHandler(this.ChildForm_FormClosing);
                    Results.Size = new Size(550, 350);
                    Results.Show();
                    this.Hide();
                }
            }
        }

        public void createClientResultsForm(MySqlDataReader reader)
        {
            // Form preparation
            int nbLabels = 0;
            // Combobox et Labels correspondants aux champs de la table client
            // "25 + nbLabels++ * 50" signifie "25 + nbLabels * 50; puis on incrémente nbLabels"
            // Numero
            ComboBox CB_Ncli = new ComboBox();
            CB_Ncli.Location = new Point(100, 25 + nbLabels * 50);
            CB_Ncli.SelectedIndexChanged += new System.EventHandler(this.MAJIndexes);
            CB_Ncli.Name = "CB_Ncli";       // Used for showing details of client in Consultation form
            Label LBL_Ncli = creerLabel(25, 25 + nbLabels++ * 50, "Ncli");

            // Nom
            ComboBox CB_Nom = new ComboBox();
            CB_Nom.Location = new Point(100, 25 + nbLabels * 50);
            CB_Nom.SelectedIndexChanged += new System.EventHandler(this.MAJIndexes);
            Label LBL_Nom = creerLabel(25, 25 + nbLabels++ * 50, "Nom");

            // Adresse
            ComboBox CB_Adresse = new ComboBox();
            CB_Adresse.Location = new Point(100, 25 + nbLabels * 50);
            CB_Adresse.SelectedIndexChanged += new System.EventHandler(this.MAJIndexes);
            Label LBL_Adresse = creerLabel(25, 25 + nbLabels++ * 50, "Adresse");

            // Localite
            ComboBox CB_Localite = new ComboBox();
            CB_Localite.Location = new Point(100, 25 + nbLabels * 50);
            CB_Localite.SelectedIndexChanged += new System.EventHandler(this.MAJIndexes);
            Label LBL_Localite = creerLabel(25, 25 + nbLabels++ * 50, "Localite");

            // Catégorie
            ComboBox CB_CAT = new ComboBox();
            CB_CAT.Location = new Point(100, 25 + nbLabels * 50);
            CB_CAT.SelectedIndexChanged += new System.EventHandler(this.MAJIndexes);
            Label LBL_CAT = creerLabel(25, 25 + nbLabels++ * 50, "(CAT)");

            // Compte
            ComboBox CB_Compte = new ComboBox();
            CB_Compte.Location = new Point(100, 25 + nbLabels * 50);
            CB_Compte.SelectedIndexChanged += new System.EventHandler(MAJIndexes);
            Label LBL_Compte = creerLabel(25, 25 + nbLabels++ * 50, "Compte");

            // Boutons
            Button BTN_Modifier = new Button();
            BTN_Modifier.Text = "Modifier";
            BTN_Modifier.Location = new Point(25, 25 + nbLabels * 50);
            BTN_Modifier.Name = "BTN_Modifier"; // Used for showing details of client in Consultation form
            BTN_Modifier.Click += delegate (object sender, EventArgs e)
            {
                Modify(sender, e, new List<List<string>>() {
                        // Liste des données de la table: nom, clés primaires
                        new List<string>() { "client", "ncli" },
                        // Liste des colonnes de la table
                        new List<string>() { "ncli", "nom", "adresse", "localite", "`(CAT)`", "compte" },
                        // Liste des nouvelles valeurs
                        new List<string>() { CB_Ncli.Text, CB_Nom.Text, CB_Adresse.Text, CB_Localite.Text, CB_CAT.Text , CB_Compte.Text }
                    });
            };
            Button BTN_Supprimer = new Button();
            BTN_Supprimer.Text = "Supprimer";
            BTN_Supprimer.Location = new Point(125, 25 + nbLabels++ * 50);
            BTN_Supprimer.Name = "BTN_Supprimer";    // Used for showing details of client in Consultation form
            BTN_Supprimer.Click += delegate (object sender, EventArgs e)
            { Delete(sender, e, CB_Ncli.Text); };


            Results.Controls.Add(CB_Ncli);
            Results.Controls.Add(CB_Nom);
            Results.Controls.Add(CB_Adresse);
            Results.Controls.Add(CB_Localite);
            Results.Controls.Add(CB_CAT);
            Results.Controls.Add(CB_Compte);

            Results.Controls.Add(LBL_Ncli);
            Results.Controls.Add(LBL_Nom);
            Results.Controls.Add(LBL_Adresse);
            Results.Controls.Add(LBL_Localite);
            Results.Controls.Add(LBL_CAT);
            Results.Controls.Add(LBL_Compte);

            Results.Controls.Add(BTN_Modifier);
            Results.Controls.Add(BTN_Supprimer);

            Results.Size = new Size(300, 50 + 50 * nbLabels);

            while (reader.Read())
            {
                int i = 0;
                CB_Ncli.Items.Add(reader.GetString(i++));
                CB_Nom.Items.Add(reader.GetString(i++));
                CB_Adresse.Items.Add(reader.GetString(i++));
                CB_Localite.Items.Add(reader.GetString(i++));
                CB_CAT.Items.Add(reader.GetString(i++));
                CB_Compte.Items.Add(reader.GetInt32(i));
            }
            this.Connection.Close();
            Results.FormClosing += new FormClosingEventHandler(this.ChildForm_FormClosing);
            Results.Show();
            this.Hide();
        }

        public void createProduitResultsForm(MySqlDataReader reader)
        {
            // Form preparation
            int nbLabels = 0;
            // Combobox et Labels correspondants aux champs de la table produits
            // "25 + nbLabels++ * 50" signifie "25 + nbLabels * 50; puis on incrémente nbLabels"
            // Numéro du produit
            ComboBox CB_Npro = new ComboBox();
            CB_Npro.Location = new Point(100, 25 + nbLabels * 50);
            CB_Npro.SelectedIndexChanged += new System.EventHandler(this.MAJIndexes);
            Label LBL_Npro = creerLabel(25, 25 + nbLabels++ * 50, "Npro");

            // Libelle
            ComboBox CB_Libelle = new ComboBox();
            CB_Libelle.Location = new Point(100, 25 + nbLabels * 50);
            CB_Libelle.SelectedIndexChanged += new System.EventHandler(this.MAJIndexes);
            Label LBL_Libelle = creerLabel(25, 25 + nbLabels++ * 50, "Libelle");

            // Prix
            ComboBox CB_Prix = new ComboBox();
            CB_Prix.Location = new Point(100, 25 + nbLabels * 50);
            CB_Prix.SelectedIndexChanged += new System.EventHandler(this.MAJIndexes);
            Label LBL_Prix = creerLabel(25, 25 + nbLabels++ * 50, "Prix");

            // Quantité en stock
            ComboBox CB_QStock = new ComboBox();
            CB_QStock.Location = new Point(100, 25 + nbLabels * 50);
            CB_QStock.SelectedIndexChanged += new System.EventHandler(this.MAJIndexes);
            Label LBL_QStock = creerLabel(25, 25 + nbLabels++ * 50, "Qstock");
            
            // Boutons
            Button BTN_Modifier = new Button();
            BTN_Modifier.Text = "Modifier";
            BTN_Modifier.Location = new Point(25, 25 + nbLabels * 50);
            BTN_Modifier.Click += delegate (object sender, EventArgs e)
            {
                Modify(sender, e, new List<List<string>>() {
                        // Liste des données de la table: nom, clés primaires
                        new List<string>() { "produit", "npro" },
                        // Liste des colonnes de la table
                        new List<string>() { "npro", "libelle", "prix", "qstock" },
                        // Liste des nouvelles valeurs
                        new List<string>() { CB_Npro.Text, CB_Libelle.Text, CB_Prix.Text, CB_QStock.Text }
                    });
            };
            Button BTN_Supprimer = new Button();
            BTN_Supprimer.Text = "Supprimer";
            BTN_Supprimer.Location = new Point(125, 25 + nbLabels++ * 50);
            BTN_Supprimer.Click += delegate (object sender, EventArgs e)
            { Delete(sender, e, CB_Npro.Text); };


            Results.Controls.Add(CB_Npro);
            Results.Controls.Add(CB_Libelle);
            Results.Controls.Add(CB_Prix);
            Results.Controls.Add(CB_QStock);

            Results.Controls.Add(LBL_Npro);
            Results.Controls.Add(LBL_Libelle);
            Results.Controls.Add(LBL_Prix);
            Results.Controls.Add(LBL_QStock);

            Results.Controls.Add(BTN_Modifier);
            Results.Controls.Add(BTN_Supprimer);

            Results.Size = new Size(300, 50 + 50 * nbLabels);

            while (reader.Read())
            {
                int i = 0;
                CB_Npro.Items.Add(reader.GetString(i++));
                CB_Libelle.Items.Add(reader.GetString(i++));
                CB_Prix.Items.Add(reader.GetString(i++));
                CB_QStock.Items.Add(reader.GetString(i));
            }
            this.Connection.Close();
            Results.FormClosing += new FormClosingEventHandler(this.ChildForm_FormClosing);
            Results.Show();
            this.Hide();
        }

        public void createCommandeResultsForm(MySqlDataReader reader)
        {
            // Form preparation
            int nbLabels = 0;
            // Combobox et Labels correspondants aux champs de la table commandes
            // "25 + nbLabels++ * 50" signifie "25 + nbLabels * 50; puis on incrémente nbLabels"
            // Numéro du produit
            ComboBox CB_Ncom = new ComboBox();
            CB_Ncom.Location = new Point(100, 25 + nbLabels * 50);
            CB_Ncom.SelectedIndexChanged += new System.EventHandler(this.MAJIndexes);
            Label LBL_Ncom = creerLabel(25, 25 + nbLabels++ * 50, "Ncom");

            // Libelle
            ComboBox CB_Ncli = new ComboBox();
            CB_Ncli.Location = new Point(100, 25 + nbLabels * 50);
            CB_Ncli.SelectedIndexChanged += new System.EventHandler(this.MAJIndexes);
            Label LBL_Ncli = creerLabel(25, 25 + nbLabels++ * 50, "Ncli");

            // Prix
            ComboBox CB_Datecom = new ComboBox();
            CB_Datecom.Location = new Point(100, 25 + nbLabels * 50);
            CB_Datecom.SelectedIndexChanged += new System.EventHandler(this.MAJIndexes);
            Label LBL_Datecom = creerLabel(25, 25 + nbLabels++ * 50, "Datecom");

            // Boutons
            Button BTN_Modifier = new Button();
            BTN_Modifier.Text = "Modifier";
            BTN_Modifier.Location = new Point(25, 25 + nbLabels * 50);
            BTN_Modifier.Click += delegate (object sender, EventArgs e)
            {
                Modify(sender, e, new List<List<string>>() {
                        // Liste des données de la table: nom, clés primaires
                        new List<string>() { "commande", "ncom" },
                        // Liste des colonnes de la table
                        new List<string>() { "ncom", "ncli", "datecom" },
                        // Liste des nouvelles valeurs
                        new List<string>() { CB_Ncom.Text, CB_Ncli.Text, CB_Datecom.Text }
                    });
            };
            Button BTN_Supprimer = new Button();
            BTN_Supprimer.Text = "Supprimer";
            BTN_Supprimer.Location = new Point(125, 25 + nbLabels++ * 50);
            BTN_Supprimer.Click += delegate (object sender, EventArgs e)
            { Delete(sender, e, CB_Ncom.Text); };


            Results.Controls.Add(CB_Ncom);
            Results.Controls.Add(CB_Ncli);
            Results.Controls.Add(CB_Datecom);

            Results.Controls.Add(LBL_Ncom);
            Results.Controls.Add(LBL_Ncli);
            Results.Controls.Add(LBL_Datecom);

            Results.Controls.Add(BTN_Modifier);
            Results.Controls.Add(BTN_Supprimer);

            Results.Size = new Size(300, 50 + 50 * nbLabels);

            while (reader.Read())
            {
                int i = 0;
                CB_Ncom.Items.Add(reader.GetString(i++));
                CB_Ncli.Items.Add(reader.GetString(i++));
                CB_Datecom.Items.Add(reader.GetString(i));
            }
            this.Connection.Close();
            Results.FormClosing += new FormClosingEventHandler(this.ChildForm_FormClosing);
            Results.Show();
            this.Hide();
        }

        public void MAJIndexes(object sender, EventArgs e)
        {
            foreach (Control c in ((Control)sender).Parent.Controls)
            {
                if (c is ComboBox  && c.Tag == ((Control)sender).Tag)
                {
                    ((ComboBox)c).SelectedIndex = ((ComboBox)sender).SelectedIndex;
                }
            }
        }

        // Only called by Comboboxes, parent is Form
        public void MAJCommandes(object sender, EventArgs e)
        {
            // Query preparation - needed no matter what

            // Attempting Database connection
            try
            {
                this.Connection.Open();
            }
            catch (Exception ex)
            {
                return;
            }

            Factures form = ((Control)sender).Parent as Factures;
            MySqlCommand command;
            string sqlCommand;
            MySqlDataReader reader;

            foreach (Control c in ((Control)sender).Parent.Controls)
            {
                if (c is ComboBox && c.Tag == ((Control)sender).Tag)
                {
                    ((ComboBox)c).SelectedIndex = ((ComboBox)sender).SelectedIndex;
                }
            }

            // If another client was selected, update list of commands and clean details
            if ((string)((Control)sender).Tag == "0")
            {
                ((ComboBox)form.Controls.Find("CB_Ncom", true).FirstOrDefault()).Items.Clear();
                ((ComboBox)form.Controls.Find("CB_Datecom", true).FirstOrDefault()).Items.Clear();
                command = this.Connection.CreateCommand();
                sqlCommand    = "SELECT ncom, DATE_FORMAT(datecom, '%Y-%m-%d') FROM commande where ncli = '" + form.Controls.Find("CB_Ncli", true).FirstOrDefault().Text + "'";
                command.CommandText = sqlCommand;
                reader = command.ExecuteReader();
                while (reader.Read())
                {
                    ((ComboBox)form.Controls.Find("CB_Ncom", true).FirstOrDefault()).Items.Add(reader.GetString(0));
                    ((ComboBox)form.Controls.Find("CB_Datecom", true).FirstOrDefault()).Items.Add(reader.GetString(1));
                }
                reader.Close();
                ((ComboBox)form.Controls.Find("CB_Ncom", true).FirstOrDefault()).Text = "";
                ((ComboBox)form.Controls.Find("CB_Datecom", true).FirstOrDefault()).Text = "";
            }

            // No matter what changed, we need to redo our detail listbox
            ((ListBox)form.Controls.Find("LB_Details", true).FirstOrDefault()).Items.Clear();
            command = this.Connection.CreateCommand();
            //sqlCommand = "SELECT npro, qcom FROM detail where ncom = '" + form.Controls.Find("CB_Ncom", true).FirstOrDefault().Text + "'";
            sqlCommand = "SELECT p.libelle, p.prix, d.qcom, p.prix*d.qcom FROM detail d, produit p where ncom = '" + form.Controls.Find("CB_Ncom", true).FirstOrDefault().Text + "' and d.npro = p.npro";
            command.CommandText = sqlCommand;
            reader = command.ExecuteReader();
            while (reader.Read())
            {
                ((ListBox)form.Controls.Find("LB_Details", true).FirstOrDefault()).Items.Add(reader.GetString(0) + "     prix " + reader.GetString(1) + "€     quantite " + reader.GetString(2) + "     (total " + reader.GetString(3) + "€)");
            }
            this.connection.Close();



        }

        public Label creerLabel(int x, int y, string text)
        {
            Label newLabel = new Label();
            newLabel.Location = new Point(x, y);
            newLabel.Text = text;
            return newLabel;
        }

        public void ChildForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (sender.GetType() == typeof(Administration))
            {
                ((Administration)sender).Caller.Show();
            }
            else if (sender.GetType() == typeof(Factures))
            {
                ((Factures)sender).Caller.Show();
            }
        }

        public void Modify(object sender, EventArgs e, List<List<String>> paramsTable)
        {
            // Attempting Database connection
            try
            {
                this.Connection.Open();
            }
            catch (Exception ex)
            {
                this.Connection.Close();
                MessageBox.Show(ex.Message);
                return;
            }

            // Command preparation
            MySqlCommand command = this.Connection.CreateCommand();
            string sqlCommand = "SELECT COUNT(*) FROM " + paramsTable[0][0] + " where " + paramsTable[1][0] + " = '" + paramsTable[2][0] + "'";
            command.CommandText = sqlCommand;

            // Attempting record counting
            int count;
            try
            {
                count = int.Parse(command.ExecuteScalar().ToString());
            }
            catch (Exception ex)
            {
                this.Connection.Close();
                MessageBox.Show(ex.Message);
                return;
            }

            if (count == 0)
            {
                // Count == 0 => No entry found, we create one
                DialogResult choixUtil = MessageBox.Show("Aucune entrée trouvée. Voulez-vous créer cette entrée ?", "Confirmer la création", MessageBoxButtons.YesNo);
                if (choixUtil == DialogResult.Yes)
                {
                    // Command preparation
                    command = this.Connection.CreateCommand();
                    sqlCommand = "INSERT INTO " + paramsTable[0][0] + " VALUES ('";
                    for (int i = 0; i < paramsTable[1].Count; i++)
                    {
                        sqlCommand += paramsTable[2][i];
                        if (i < paramsTable[1].Count - 1)
                        {
                            sqlCommand += "', '";
                        }
                    }
                    sqlCommand += "')";
                    command.CommandText = sqlCommand;
                    // Attempting record counting
                    try
                    {
                        command.ExecuteScalar();
                    }
                    catch (Exception ex)
                    {
                        this.Connection.Close();
                        MessageBox.Show(ex.Message);
                        return;
                    }
                    this.Connection.Close();
                    MessageBox.Show("Entrée créée !");
                        }
                else
                {
                    this.Connection.Close();
                    MessageBox.Show("Annulation de la création");
                }
            }
            else
            {
                // Count > 0 => Entry found, we update it
                DialogResult choixUtil = MessageBox.Show("Une entrée a été trouvée. Voulez-vous mettre à jour cette entrée ?", "Confirmer la mise à jour", MessageBoxButtons.YesNo);
                if (choixUtil == DialogResult.Yes)
                {
                    // Command preparation
                    command = this.Connection.CreateCommand();
                    sqlCommand = "UPDATE " + paramsTable[0][0] + " SET ";
                    for (int i = 0; i < paramsTable[1].Count; i++)
                    {
                        sqlCommand += paramsTable[1][i] + " = '" + paramsTable[2][i] + "'";
                        if (i < paramsTable[1].Count - 1)
                        {
                            sqlCommand += ", ";
                        }
                    }
                    sqlCommand += " WHERE " + paramsTable[1][0] + " = '" + paramsTable[2][0] +"'";
                    command.CommandText = sqlCommand;
                    // Attempting record counti ng
                    try
                    {
                        command.ExecuteScalar();
                    }
                    catch (Exception ex)
                    {
                        this.Connection.Close();
                        MessageBox.Show(ex.Message);
                        return;
                    }
                    this.Connection.Close();
                    MessageBox.Show("Entrée mise à jour !");
                }
                else
                {
                    this.Connection.Close();
                    MessageBox.Show("Annulation de la mise à jour");
                }
            }
        }

        public void Delete(object sender, EventArgs e, string numClient)
        {
            DialogResult choixUtil = MessageBox.Show("Voulez-vous vraiment supprimer l'enregistrement sélectionné ?", "Confirmer la suppression", MessageBoxButtons.YesNo);
            if (choixUtil == DialogResult.Yes)
            {
                // Attempting Database connection
                try
                {
                    this.Connection.Open();
                }
                catch (Exception ex)
                {
                    this.Connection.Close();
                    MessageBox.Show(ex.Message);
                    return;
                }

                // Command preparation
                MySqlCommand command = this.Connection.CreateCommand();
                string sqlCommand = "DELETE FROM client where ncli = '" + numClient + "'";
                command.CommandText = sqlCommand;

                // Attempting record deleting
                try
                {
                    command.ExecuteScalar();
                }
                    catch (Exception ex)
                {
                    this.Connection.Close();
                    MessageBox.Show(ex.Message);
                    return;
                }

                this.Connection.Close();
                MessageBox.Show("Entrée supprimée !");
            }
            else
            {
                this.Connection.Close();
                MessageBox.Show("Annulation de la suppression");
            }
        }
    }
}
