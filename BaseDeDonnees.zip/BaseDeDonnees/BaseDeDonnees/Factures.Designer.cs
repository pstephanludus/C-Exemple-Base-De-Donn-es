﻿namespace BaseDeDonnees
{
    partial class Factures
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Factures));
            this.CB_Ncli = new System.Windows.Forms.ComboBox();
            this.LBL_Client = new System.Windows.Forms.Label();
            this.CB_Nom = new System.Windows.Forms.ComboBox();
            this.BTN_Details = new System.Windows.Forms.Button();
            this.LBL_Commande = new System.Windows.Forms.Label();
            this.CB_DateCom = new System.Windows.Forms.ComboBox();
            this.CB_Ncom = new System.Windows.Forms.ComboBox();
            this.LB_Details = new System.Windows.Forms.ListBox();
            this.LBL_Ncli = new System.Windows.Forms.Label();
            this.LBL_Nom = new System.Windows.Forms.Label();
            this.LBL_DateCom = new System.Windows.Forms.Label();
            this.LBL_Ncom = new System.Windows.Forms.Label();
            this.LBL_Detail = new System.Windows.Forms.Label();
            this.BTN_GenFacture = new System.Windows.Forms.Button();
            this.BTN_AddProduct = new System.Windows.Forms.Button();
            this.BTN_RemoveProduct = new System.Windows.Forms.Button();
            this.LBL_Quantite = new System.Windows.Forms.Label();
            this.CB_Prix = new System.Windows.Forms.ComboBox();
            this.CB_Produit = new System.Windows.Forms.ComboBox();
            this.LBL_Produit = new System.Windows.Forms.Label();
            this.LBL_Prix = new System.Windows.Forms.Label();
            this.LBL_QuantiteStock = new System.Windows.Forms.Label();
            this.CB_QuantiteStock = new System.Windows.Forms.ComboBox();
            this.LBL_GenererModifier = new System.Windows.Forms.Label();
            this.NUD_Quantite = new System.Windows.Forms.NumericUpDown();
            this.CB_Npro = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_Quantite)).BeginInit();
            this.SuspendLayout();
            // 
            // CB_Ncli
            // 
            this.CB_Ncli.FormattingEnabled = true;
            this.CB_Ncli.Location = new System.Drawing.Point(101, 54);
            this.CB_Ncli.Name = "CB_Ncli";
            this.CB_Ncli.Size = new System.Drawing.Size(121, 21);
            this.CB_Ncli.TabIndex = 0;
            this.CB_Ncli.Tag = "0";
            // 
            // LBL_Client
            // 
            this.LBL_Client.AutoSize = true;
            this.LBL_Client.Location = new System.Drawing.Point(16, 57);
            this.LBL_Client.Name = "LBL_Client";
            this.LBL_Client.Size = new System.Drawing.Size(33, 13);
            this.LBL_Client.TabIndex = 12;
            this.LBL_Client.Text = "Client";
            // 
            // CB_Nom
            // 
            this.CB_Nom.FormattingEnabled = true;
            this.CB_Nom.Location = new System.Drawing.Point(227, 54);
            this.CB_Nom.Name = "CB_Nom";
            this.CB_Nom.Size = new System.Drawing.Size(144, 21);
            this.CB_Nom.TabIndex = 1;
            this.CB_Nom.Tag = "0";
            // 
            // BTN_Details
            // 
            this.BTN_Details.Location = new System.Drawing.Point(393, 54);
            this.BTN_Details.Name = "BTN_Details";
            this.BTN_Details.Size = new System.Drawing.Size(112, 23);
            this.BTN_Details.TabIndex = 2;
            this.BTN_Details.Text = "Détails clients";
            this.BTN_Details.UseVisualStyleBackColor = true;
            this.BTN_Details.Click += new System.EventHandler(this.BTN_Details_Click);
            // 
            // LBL_Commande
            // 
            this.LBL_Commande.AutoSize = true;
            this.LBL_Commande.Location = new System.Drawing.Point(16, 133);
            this.LBL_Commande.Name = "LBL_Commande";
            this.LBL_Commande.Size = new System.Drawing.Size(60, 13);
            this.LBL_Commande.TabIndex = 15;
            this.LBL_Commande.Text = "Commande";
            // 
            // CB_DateCom
            // 
            this.CB_DateCom.FormattingEnabled = true;
            this.CB_DateCom.Location = new System.Drawing.Point(227, 130);
            this.CB_DateCom.Name = "CB_DateCom";
            this.CB_DateCom.Size = new System.Drawing.Size(144, 21);
            this.CB_DateCom.TabIndex = 4;
            this.CB_DateCom.Tag = "1";
            // 
            // CB_Ncom
            // 
            this.CB_Ncom.FormattingEnabled = true;
            this.CB_Ncom.Location = new System.Drawing.Point(100, 130);
            this.CB_Ncom.Name = "CB_Ncom";
            this.CB_Ncom.Size = new System.Drawing.Size(121, 21);
            this.CB_Ncom.TabIndex = 3;
            this.CB_Ncom.Tag = "1";
            // 
            // LB_Details
            // 
            this.LB_Details.FormattingEnabled = true;
            this.LB_Details.Location = new System.Drawing.Point(100, 198);
            this.LB_Details.Name = "LB_Details";
            this.LB_Details.Size = new System.Drawing.Size(405, 95);
            this.LB_Details.TabIndex = 19;
            // 
            // LBL_Ncli
            // 
            this.LBL_Ncli.AutoSize = true;
            this.LBL_Ncli.Location = new System.Drawing.Point(101, 23);
            this.LBL_Ncli.Name = "LBL_Ncli";
            this.LBL_Ncli.Size = new System.Drawing.Size(87, 13);
            this.LBL_Ncli.TabIndex = 13;
            this.LBL_Ncli.Text = "Numéro de client";
            // 
            // LBL_Nom
            // 
            this.LBL_Nom.AutoSize = true;
            this.LBL_Nom.Location = new System.Drawing.Point(224, 23);
            this.LBL_Nom.Name = "LBL_Nom";
            this.LBL_Nom.Size = new System.Drawing.Size(72, 13);
            this.LBL_Nom.TabIndex = 14;
            this.LBL_Nom.Text = "Nom du client";
            // 
            // LBL_DateCom
            // 
            this.LBL_DateCom.AutoSize = true;
            this.LBL_DateCom.Location = new System.Drawing.Point(224, 101);
            this.LBL_DateCom.Name = "LBL_DateCom";
            this.LBL_DateCom.Size = new System.Drawing.Size(100, 13);
            this.LBL_DateCom.TabIndex = 17;
            this.LBL_DateCom.Text = "Date de commande";
            // 
            // LBL_Ncom
            // 
            this.LBL_Ncom.AutoSize = true;
            this.LBL_Ncom.Location = new System.Drawing.Point(101, 101);
            this.LBL_Ncom.Name = "LBL_Ncom";
            this.LBL_Ncom.Size = new System.Drawing.Size(114, 13);
            this.LBL_Ncom.TabIndex = 16;
            this.LBL_Ncom.Text = "Numéro de commande";
            // 
            // LBL_Detail
            // 
            this.LBL_Detail.AutoSize = true;
            this.LBL_Detail.Location = new System.Drawing.Point(19, 198);
            this.LBL_Detail.Name = "LBL_Detail";
            this.LBL_Detail.Size = new System.Drawing.Size(34, 13);
            this.LBL_Detail.TabIndex = 18;
            this.LBL_Detail.Text = "Detail";
            // 
            // BTN_GenFacture
            // 
            this.BTN_GenFacture.AutoSize = true;
            this.BTN_GenFacture.Location = new System.Drawing.Point(393, 121);
            this.BTN_GenFacture.Name = "BTN_GenFacture";
            this.BTN_GenFacture.Size = new System.Drawing.Size(112, 36);
            this.BTN_GenFacture.TabIndex = 5;
            this.BTN_GenFacture.Text = "Générer / modifier \r\nune facture";
            this.BTN_GenFacture.UseVisualStyleBackColor = true;
            this.BTN_GenFacture.Click += new System.EventHandler(this.BTN_GenFacture_Click);
            // 
            // BTN_AddProduct
            // 
            this.BTN_AddProduct.Image = ((System.Drawing.Image)(resources.GetObject("BTN_AddProduct.Image")));
            this.BTN_AddProduct.Location = new System.Drawing.Point(436, 324);
            this.BTN_AddProduct.Name = "BTN_AddProduct";
            this.BTN_AddProduct.Size = new System.Drawing.Size(50, 50);
            this.BTN_AddProduct.TabIndex = 8;
            this.BTN_AddProduct.UseVisualStyleBackColor = true;
            this.BTN_AddProduct.Click += new System.EventHandler(this.BTN_AddProduct_Click);
            // 
            // BTN_RemoveProduct
            // 
            this.BTN_RemoveProduct.Image = ((System.Drawing.Image)(resources.GetObject("BTN_RemoveProduct.Image")));
            this.BTN_RemoveProduct.Location = new System.Drawing.Point(117, 324);
            this.BTN_RemoveProduct.Name = "BTN_RemoveProduct";
            this.BTN_RemoveProduct.Size = new System.Drawing.Size(50, 50);
            this.BTN_RemoveProduct.TabIndex = 6;
            this.BTN_RemoveProduct.UseVisualStyleBackColor = true;
            this.BTN_RemoveProduct.Click += new System.EventHandler(this.BTN_RemoveProduct_Click);
            // 
            // LBL_Quantite
            // 
            this.LBL_Quantite.AutoSize = true;
            this.LBL_Quantite.Location = new System.Drawing.Point(261, 324);
            this.LBL_Quantite.Name = "LBL_Quantite";
            this.LBL_Quantite.Size = new System.Drawing.Size(91, 13);
            this.LBL_Quantite.TabIndex = 21;
            this.LBL_Quantite.Text = "Quantité à ajouter";
            // 
            // CB_Prix
            // 
            this.CB_Prix.FormattingEnabled = true;
            this.CB_Prix.Location = new System.Drawing.Point(304, 408);
            this.CB_Prix.Name = "CB_Prix";
            this.CB_Prix.Size = new System.Drawing.Size(88, 21);
            this.CB_Prix.TabIndex = 10;
            this.CB_Prix.Tag = "2";
            // 
            // CB_Produit
            // 
            this.CB_Produit.FormattingEnabled = true;
            this.CB_Produit.Location = new System.Drawing.Point(117, 408);
            this.CB_Produit.Name = "CB_Produit";
            this.CB_Produit.Size = new System.Drawing.Size(179, 21);
            this.CB_Produit.TabIndex = 9;
            this.CB_Produit.Tag = "2";
            // 
            // LBL_Produit
            // 
            this.LBL_Produit.AutoSize = true;
            this.LBL_Produit.Location = new System.Drawing.Point(114, 392);
            this.LBL_Produit.Name = "LBL_Produit";
            this.LBL_Produit.Size = new System.Drawing.Size(40, 13);
            this.LBL_Produit.TabIndex = 22;
            this.LBL_Produit.Text = "Produit";
            // 
            // LBL_Prix
            // 
            this.LBL_Prix.AutoSize = true;
            this.LBL_Prix.Location = new System.Drawing.Point(301, 392);
            this.LBL_Prix.Name = "LBL_Prix";
            this.LBL_Prix.Size = new System.Drawing.Size(24, 13);
            this.LBL_Prix.TabIndex = 23;
            this.LBL_Prix.Text = "Prix";
            // 
            // LBL_QuantiteStock
            // 
            this.LBL_QuantiteStock.AutoSize = true;
            this.LBL_QuantiteStock.Location = new System.Drawing.Point(395, 392);
            this.LBL_QuantiteStock.Name = "LBL_QuantiteStock";
            this.LBL_QuantiteStock.Size = new System.Drawing.Size(91, 13);
            this.LBL_QuantiteStock.TabIndex = 24;
            this.LBL_QuantiteStock.Text = "Quantité en stock";
            // 
            // CB_QuantiteStock
            // 
            this.CB_QuantiteStock.FormattingEnabled = true;
            this.CB_QuantiteStock.Location = new System.Drawing.Point(398, 408);
            this.CB_QuantiteStock.Name = "CB_QuantiteStock";
            this.CB_QuantiteStock.Size = new System.Drawing.Size(88, 21);
            this.CB_QuantiteStock.TabIndex = 11;
            this.CB_QuantiteStock.Tag = "2";
            // 
            // LBL_GenererModifier
            // 
            this.LBL_GenererModifier.AutoSize = true;
            this.LBL_GenererModifier.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)), true);
            this.LBL_GenererModifier.Location = new System.Drawing.Point(16, 324);
            this.LBL_GenererModifier.Name = "LBL_GenererModifier";
            this.LBL_GenererModifier.Size = new System.Drawing.Size(95, 26);
            this.LBL_GenererModifier.TabIndex = 20;
            this.LBL_GenererModifier.Text = "Générer / modifier \r\n      la facture";
            // 
            // NUD_Quantite
            // 
            this.NUD_Quantite.Location = new System.Drawing.Point(264, 340);
            this.NUD_Quantite.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.NUD_Quantite.Name = "NUD_Quantite";
            this.NUD_Quantite.Size = new System.Drawing.Size(120, 20);
            this.NUD_Quantite.TabIndex = 25;
            this.NUD_Quantite.ValueChanged += new System.EventHandler(this.NUD_Quantite_ValueChanged);
            // 
            // CB_Npro
            // 
            this.CB_Npro.FormattingEnabled = true;
            this.CB_Npro.Location = new System.Drawing.Point(13, 407);
            this.CB_Npro.Name = "CB_Npro";
            this.CB_Npro.Size = new System.Drawing.Size(40, 21);
            this.CB_Npro.TabIndex = 26;
            this.CB_Npro.Tag = "2";
            this.CB_Npro.Visible = false;
            // 
            // Factures
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 461);
            this.Controls.Add(this.CB_Npro);
            this.Controls.Add(this.NUD_Quantite);
            this.Controls.Add(this.LBL_GenererModifier);
            this.Controls.Add(this.CB_QuantiteStock);
            this.Controls.Add(this.LBL_QuantiteStock);
            this.Controls.Add(this.LBL_Prix);
            this.Controls.Add(this.LBL_Produit);
            this.Controls.Add(this.CB_Produit);
            this.Controls.Add(this.CB_Prix);
            this.Controls.Add(this.LBL_Quantite);
            this.Controls.Add(this.BTN_RemoveProduct);
            this.Controls.Add(this.BTN_AddProduct);
            this.Controls.Add(this.LBL_Detail);
            this.Controls.Add(this.LBL_DateCom);
            this.Controls.Add(this.LBL_Ncom);
            this.Controls.Add(this.LBL_Nom);
            this.Controls.Add(this.LBL_Ncli);
            this.Controls.Add(this.LB_Details);
            this.Controls.Add(this.CB_DateCom);
            this.Controls.Add(this.CB_Ncom);
            this.Controls.Add(this.LBL_Commande);
            this.Controls.Add(this.BTN_Details);
            this.Controls.Add(this.CB_Nom);
            this.Controls.Add(this.BTN_GenFacture);
            this.Controls.Add(this.LBL_Client);
            this.Controls.Add(this.CB_Ncli);
            this.Name = "Factures";
            this.Text = "Factures";
            ((System.ComponentModel.ISupportInitialize)(this.NUD_Quantite)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox CB_Ncli;
        private System.Windows.Forms.Label LBL_Client;
        private System.Windows.Forms.ComboBox CB_Nom;
        private System.Windows.Forms.Button BTN_Details;
        private System.Windows.Forms.Label LBL_Commande;
        private System.Windows.Forms.ComboBox CB_DateCom;
        private System.Windows.Forms.ComboBox CB_Ncom;
        private System.Windows.Forms.ListBox LB_Details;
        private System.Windows.Forms.Label LBL_Ncli;
        private System.Windows.Forms.Label LBL_Nom;
        private System.Windows.Forms.Label LBL_DateCom;
        private System.Windows.Forms.Label LBL_Ncom;
        private System.Windows.Forms.Label LBL_Detail;
        private System.Windows.Forms.Button BTN_GenFacture;
        private System.Windows.Forms.Button BTN_AddProduct;
        private System.Windows.Forms.Label LBL_Quantite;
        private System.Windows.Forms.ComboBox CB_Prix;
        private System.Windows.Forms.ComboBox CB_Produit;
        private System.Windows.Forms.Label LBL_Produit;
        private System.Windows.Forms.Label LBL_Prix;
        private System.Windows.Forms.Label LBL_QuantiteStock;
        private System.Windows.Forms.ComboBox CB_QuantiteStock;
        private System.Windows.Forms.Label LBL_GenererModifier;
        private System.Windows.Forms.NumericUpDown NUD_Quantite;
        protected System.Windows.Forms.Button BTN_RemoveProduct;
        private System.Windows.Forms.ComboBox CB_Npro;
    }
}