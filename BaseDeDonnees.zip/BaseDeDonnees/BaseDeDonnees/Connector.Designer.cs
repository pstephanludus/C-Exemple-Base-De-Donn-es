﻿namespace BaseDeDonnees
{
    partial class Connector
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.TB_Password = new System.Windows.Forms.TextBox();
            this.TB_User = new System.Windows.Forms.TextBox();
            this.TB_InitCatalog = new System.Windows.Forms.TextBox();
            this.TB_Source = new System.Windows.Forms.TextBox();
            this.LBL_Source = new System.Windows.Forms.Label();
            this.LBL_InitCatalog = new System.Windows.Forms.Label();
            this.LBL_User = new System.Windows.Forms.Label();
            this.LBL_Password = new System.Windows.Forms.Label();
            this.BTN_Connection = new System.Windows.Forms.Button();
            this.LBL_Table = new System.Windows.Forms.Label();
            this.TB_Table = new System.Windows.Forms.TextBox();
            this.LBL_Mode = new System.Windows.Forms.Label();
            this.CB_Mode = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // TB_Password
            // 
            this.TB_Password.Location = new System.Drawing.Point(143, 170);
            this.TB_Password.Name = "TB_Password";
            this.TB_Password.Size = new System.Drawing.Size(79, 20);
            this.TB_Password.TabIndex = 4;
            // 
            // TB_User
            // 
            this.TB_User.Location = new System.Drawing.Point(143, 144);
            this.TB_User.Name = "TB_User";
            this.TB_User.Size = new System.Drawing.Size(79, 20);
            this.TB_User.TabIndex = 3;
            // 
            // TB_InitCatalog
            // 
            this.TB_InitCatalog.Location = new System.Drawing.Point(143, 91);
            this.TB_InitCatalog.Name = "TB_InitCatalog";
            this.TB_InitCatalog.Size = new System.Drawing.Size(79, 20);
            this.TB_InitCatalog.TabIndex = 2;
            // 
            // TB_Source
            // 
            this.TB_Source.Location = new System.Drawing.Point(143, 65);
            this.TB_Source.Name = "TB_Source";
            this.TB_Source.Size = new System.Drawing.Size(79, 20);
            this.TB_Source.TabIndex = 1;
            // 
            // LBL_Source
            // 
            this.LBL_Source.AutoSize = true;
            this.LBL_Source.Location = new System.Drawing.Point(46, 68);
            this.LBL_Source.Name = "LBL_Source";
            this.LBL_Source.Size = new System.Drawing.Size(41, 13);
            this.LBL_Source.TabIndex = 7;
            this.LBL_Source.Text = "Source";
            // 
            // LBL_InitCatalog
            // 
            this.LBL_InitCatalog.AutoSize = true;
            this.LBL_InitCatalog.Location = new System.Drawing.Point(46, 94);
            this.LBL_InitCatalog.Name = "LBL_InitCatalog";
            this.LBL_InitCatalog.Size = new System.Drawing.Size(70, 13);
            this.LBL_InitCatalog.TabIndex = 8;
            this.LBL_InitCatalog.Text = "Initial Catalog";
            // 
            // LBL_User
            // 
            this.LBL_User.AutoSize = true;
            this.LBL_User.Location = new System.Drawing.Point(46, 147);
            this.LBL_User.Name = "LBL_User";
            this.LBL_User.Size = new System.Drawing.Size(29, 13);
            this.LBL_User.TabIndex = 9;
            this.LBL_User.Text = "User";
            // 
            // LBL_Password
            // 
            this.LBL_Password.AutoSize = true;
            this.LBL_Password.Location = new System.Drawing.Point(46, 173);
            this.LBL_Password.Name = "LBL_Password";
            this.LBL_Password.Size = new System.Drawing.Size(53, 13);
            this.LBL_Password.TabIndex = 10;
            this.LBL_Password.Text = "Password";
            // 
            // BTN_Connection
            // 
            this.BTN_Connection.Location = new System.Drawing.Point(143, 226);
            this.BTN_Connection.Name = "BTN_Connection";
            this.BTN_Connection.Size = new System.Drawing.Size(75, 23);
            this.BTN_Connection.TabIndex = 0;
            this.BTN_Connection.Text = "Connection";
            this.BTN_Connection.UseVisualStyleBackColor = true;
            this.BTN_Connection.Click += new System.EventHandler(this.BTN_Connection_Click);
            // 
            // LBL_Table
            // 
            this.LBL_Table.AutoSize = true;
            this.LBL_Table.Location = new System.Drawing.Point(46, 120);
            this.LBL_Table.Name = "LBL_Table";
            this.LBL_Table.Size = new System.Drawing.Size(34, 13);
            this.LBL_Table.TabIndex = 13;
            this.LBL_Table.Text = "Table";
            // 
            // TB_Table
            // 
            this.TB_Table.Location = new System.Drawing.Point(143, 117);
            this.TB_Table.Name = "TB_Table";
            this.TB_Table.Size = new System.Drawing.Size(79, 20);
            this.TB_Table.TabIndex = 12;
            // 
            // LBL_Mode
            // 
            this.LBL_Mode.AutoSize = true;
            this.LBL_Mode.Location = new System.Drawing.Point(46, 200);
            this.LBL_Mode.Name = "LBL_Mode";
            this.LBL_Mode.Size = new System.Drawing.Size(34, 13);
            this.LBL_Mode.TabIndex = 14;
            this.LBL_Mode.Text = "Mode";
            // 
            // CB_Mode
            // 
            this.CB_Mode.FormattingEnabled = true;
            this.CB_Mode.Items.AddRange(new object[] {
            "Administration",
            "Factures"});
            this.CB_Mode.Location = new System.Drawing.Point(143, 197);
            this.CB_Mode.Name = "CB_Mode";
            this.CB_Mode.Size = new System.Drawing.Size(79, 21);
            this.CB_Mode.TabIndex = 15;
            // 
            // Connector
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.CB_Mode);
            this.Controls.Add(this.LBL_Mode);
            this.Controls.Add(this.LBL_Table);
            this.Controls.Add(this.TB_Table);
            this.Controls.Add(this.BTN_Connection);
            this.Controls.Add(this.LBL_Password);
            this.Controls.Add(this.LBL_User);
            this.Controls.Add(this.LBL_InitCatalog);
            this.Controls.Add(this.LBL_Source);
            this.Controls.Add(this.TB_Source);
            this.Controls.Add(this.TB_InitCatalog);
            this.Controls.Add(this.TB_User);
            this.Controls.Add(this.TB_Password);
            this.Name = "Connector";
            this.Text = "Connect to database";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TB_Password;
        private System.Windows.Forms.TextBox TB_User;
        private System.Windows.Forms.TextBox TB_InitCatalog;
        private System.Windows.Forms.TextBox TB_Source;
        private System.Windows.Forms.Label LBL_Source;
        private System.Windows.Forms.Label LBL_InitCatalog;
        private System.Windows.Forms.Label LBL_User;
        private System.Windows.Forms.Label LBL_Password;
        private System.Windows.Forms.Button BTN_Connection;
        private System.Windows.Forms.Label LBL_Table;
        private System.Windows.Forms.TextBox TB_Table;
        private System.Windows.Forms.Label LBL_Mode;
        private System.Windows.Forms.ComboBox CB_Mode;
    }
}

