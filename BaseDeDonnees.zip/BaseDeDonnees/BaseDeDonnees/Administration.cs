﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BaseDeDonnees
{
    public partial class Administration : Form
    {
        Form caller;

        public Administration(Form caller)
        {
            this.Caller = caller;
            InitializeComponent();
        }

        public Form Caller
        {
            get
            {
                return caller;
            }

            set
            {
                caller = value;
            }
        }
    }
}
