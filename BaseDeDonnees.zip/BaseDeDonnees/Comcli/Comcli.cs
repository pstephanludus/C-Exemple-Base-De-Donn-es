﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Comcli
{
    public class Client
    {
        public int NCLI { get; set; }
        public int LOGIN { get; set; }
        public int PASSWORD { get; set; }
        public int NOM { get; set; }
        public int ADRESSE { get; set; }
        public int LOCALITE { get; set; }
        public int CAT { get; set; }
        public int COMPTE { get; set; }
    }

    public class Commande
    {
        public int NCOM { get; set; }
        public int NCLI { get; set; }
        public int DATECOM { get; set; }
    }

    public class Detail
    {
        public int NCOM { get; set; }
        public int NPRO { get; set; }
        public int QCOM { get; set; }
    }

    public class produit
    {
        public int NPRO { get; set; }
        public int LIBELLE { get; set; }
        public int PRIX { get; set; }
        public int QSTOCK { get; set; }
    }
}
