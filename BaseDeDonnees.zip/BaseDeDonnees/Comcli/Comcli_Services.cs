﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Configuration;
using Common.Comcli;

namespace Common.Services
{
    class Client_Services
    {
        public void Connection()
        {
            try
            {
                MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["comCliConnection"].ConnectionString);
                connection.Open();
                string commandText = "SELECT * FROM client";
                MySqlCommand command = new MySqlCommand(commandText, connection);
                MySqlDataReader reader = command.ExecuteReader();

                List<Client> clients = new List<Client>();



                connection.Close();
            }
            catch(Exception e)
            {

            }
        }
    }
}
